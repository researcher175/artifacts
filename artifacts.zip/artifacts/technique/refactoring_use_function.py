from rope.base.project import Project
from rope.refactor.usefunction import UseFunction
from custom_logger import CustomLogger
from refactoring_base import BaseRefactoring


class UseFunctionRefactoring(BaseRefactoring):

    def apply(self):
        CustomLogger.instance().logger(
            message='Use function refactoring: self.file_to_rename: {} | self.from_position: {}'.format(
                self.file_to_refactor, self.from_position))
        try:
            project = Project(self.project_folder)
            from_move_file = self.find_module_in_project(project, self.file_to_refactor)
            changes = UseFunction(project, from_move_file, self.from_position)

            project.do(changes.get_changes())
        except Exception as err:
            CustomLogger.instance().logger('Error during refactoring application. Err: {}'.format(err))
            raise ValueError(err)

    def __init__(self, file_to_refactor, from_position, project_folder='./'):
        self.file_to_refactor = file_to_refactor
        self.from_position = from_position
        self.project_folder = project_folder
        self.to_rename = ''