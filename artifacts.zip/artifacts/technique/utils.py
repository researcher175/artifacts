import os
import shutil
from subprocess import Popen, PIPE, STDOUT
from shlex import split
import sys
import textwrap

from custom_logger import CustomLogger


class Utils:

    @staticmethod
    def remove_file(file):
        if os.path.exists(file):
            os.remove(file)
        else:
            print('The file {} does not exist'.format(file))

    @staticmethod
    def write_file(file_name, body):
        file = open(file_name, 'w')
        file.write(body)
        file.close()

    @staticmethod
    def append_to_file(file_name, body):
        file = open(file_name, 'a')
        file.write(body)
        file.close()

    @staticmethod
    def clone_file(source, destination):
        logger = CustomLogger.instance()
        logger.logger('Cloning test file {} to {}'.format(source, destination))
        try:
            shutil.copy(source, destination)
        except Exception as err:
            logger.logger('Error to clone file: {}'.format(err))
            os.makedirs(os.path.dirname(destination))
            open(destination, 'a').close()
            shutil.copy(source, destination)
            logger.logger('Success to clone file.')

    @staticmethod
    def clone_file_with_replacement(source, dest, replace=False, replace_from='', replace_to=''):
        with open(source, 'r') as file:
            data = file.read()
            if replace:
                data = data.replace(replace_from, replace_to)

        with open(dest, 'w') as file:
            file.write(data)

    @staticmethod
    def file_exists(path):
        return os.path.exists(path)

    @staticmethod
    def get_position(file, search_term):
        with open(file, 'r') as file:
            data = file.read()

        return data.find(search_term)

    @staticmethod
    def file_selector(folder, test=True):
        py_files = []

        for root, dirs, files in os.walk(folder, topdown=True):

            for name in files:
                path = os.path.join(root, name)

                without_test = (
                        name.endswith('.py')
                        and "setup" not in name
                        and not name.startswith('_')
                        and 'docs' not in path
                        and 'labs' not in path
                        and 'buggy' not in path
                        and 'release' not in path
                        and 'tasks' not in path
                        and '/examples' not in path
                )
                with_test = (
                        without_test
                        and 'test' not in path
                        and 'tests' not in path
                )

                if (test and with_test) or (not test and without_test):
                    py_files.append(path)

        return py_files

    @staticmethod
    def run_command(cmd):
        try:
            process = Popen(split(cmd), stdout=PIPE, stderr=STDOUT, encoding='utf8')
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    print("End of output")
                    break
                if output:
                    CustomLogger.instance().logger(output.strip())
            rc = process.poll()
            return rc
        except KeyboardInterrupt:
            # process.terminate()
            exit()
        except Exception as ex:
            print("Encountered an error : ", ex)
