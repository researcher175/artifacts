import ast
import tokenize
import keyword
import collections
import nltk


from custom_logger import CustomLogger
from collections import deque


class FuncCallVisitor(ast.NodeVisitor):
    def __init__(self):
        self._name = deque()

    @property
    def name(self):
        return '.'.join(self._name)

    @name.deleter
    def name(self):
        self._name.clear()

    def visit_Name(self, node):
        self._name.appendleft(node.id)

    def visit_Attribute(self, node):
        try:
            self._name.appendleft(node.attr)
            self._name.appendleft(node.value.id)
        except AttributeError:
            self.generic_visit(node)


class AstUtils:

    @staticmethod
    def get_variables(file, log=True):
        with open(file) as f:
            code = f.read()

        tree = ast.parse(code)

        assignments = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.Assign)
        ]

        target_variables = {}
        for a in assignments:

            for target in a.targets:

                if isinstance(target, ast.Name):
                    position = 0

                    if hasattr(a, "lineno") and hasattr(a, "col_offset"):
                        position = AstUtils.get_term_offset(file, a.lineno, a.col_offset)

                    if target.id in target_variables.keys():
                        if target_variables[target.id] > position:
                            target_variables[target.id] = position
                    else:
                        target_variables[target.id] = position


        if log:
            CustomLogger.instance().logger("Found {} assignments to these variable names: {}".format(len(target_variables), target_variables))
        return target_variables

    @staticmethod
    def get_term_offset(file, line, col):
        offset = 0
        read_lines = 0
        with open(file, 'r') as file:

            for read_line in file:
                read_lines += 1

                if read_lines == line:
                    offset += col
                    break
                else:
                    offset += len(read_line)

        return offset

    @staticmethod
    def get_methods(file, globals=False, log=True):
        with open(file) as f:
            code = f.read()

        tree = ast.parse(code)

        functions = [
            node
            for node in ast.walk(tree)
            if (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.col_offset == 0) or (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not globals)
        ]

        target_functions = {}

        for function in functions:

            if function.name not in target_functions.keys() and function.name != '__init__':
                target_functions[function.name] = AstUtils.get_term_offset(file, function.lineno, function.col_offset) + 4

        if log:
            CustomLogger.instance().logger("Found {} these functions: {}".format(len(target_functions), target_functions))
        return target_functions

    @staticmethod
    def get_functions_calls(file):

        with open(file) as f:
            code = f.read()

        tree = ast.parse(code)

        calls = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
        ]

        target_calls = {}

        for call in calls:
            visitor = FuncCallVisitor()
            visitor.visit(call)
            function_name = visitor.name
            if function_name != 'print' and function_name not in target_calls.keys():
                target_calls[function_name] = AstUtils.get_term_offset(file, call.lineno, call.col_offset+1)

        return target_calls


    @staticmethod
    def get_keywords_in_file(file, python_file=True):

        with open(file) as f:
            if python_file:
                tokens = (token for _, token, _, _, _ in tokenize.generate_tokens(f.readline))
                c = collections.Counter(token for token in tokens if keyword.iskeyword(token))
            else:
                c = AstUtils.get_keywords(f)

        return dict(c)


    @staticmethod
    def get_keywords_count(file):
        return len(AstUtils.get_keywords_in_file(file))


    @staticmethod
    def get_classes(file):
        with open(file) as f:
            code = f.read()

        tree = ast.parse(code)

        assignments = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.ClassDef)
        ]

        # print(assignments)
        return len(assignments)

    @classmethod
    def get_keywords(cls, f):
        keywords = {}
        matches = nltk.word_tokenize(f.read())

        for word in matches:
            if keyword.iskeyword(word):
                if word not in keywords.keys():
                    keywords[word] = 1
                else:
                    keywords[word] += 1

        return keywords
