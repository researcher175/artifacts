from git import Repo

from custom_logger import CustomLogger
from utils import Utils


class GitController:

    def __init__(self, repository):
        self.repository = Repo(repository)

    def checkout_all(self):
        paths = self.repository.git.checkout('.')
        CustomLogger.instance().logger('Git checkout: Paths: {}'.format(paths))

    def get_diff(self):
        repo_diff = ''
        for diff_item in self.repository.index.diff(None, create_patch=True):
            repo_diff += (
                f"--- a/{diff_item.a_blob.name}\n+++ b/{diff_item.b_blob.name}\n"
                f"{diff_item.diff.decode('utf-8')}\n\n"
            )
        print(repo_diff)
        return repo_diff

    def set_origin(self, new_origin):
        self.repository.remote(name=new_origin)

    def create_and_checkout_to_branch(self, branch):
        CustomLogger.instance().logger('Git create and checkout to branch: {}'.format(branch))
        self.repository.git.checkout('HEAD', b=branch)

    def checkout_to_branch(self, branch):
        CustomLogger.instance().logger('Git checkout to branch: {}'.format(branch))
        self.repository.git.checkout(branch)

    def commit_and_push_to_remote(self, commit_message):
        CustomLogger.instance().logger('Git adding files')
        self.repository.git.add('.')

        CustomLogger.instance().logger('Git commit. Message: {}'.format(commit_message))
        self.repository.git.commit('-m', commit_message)

        CustomLogger.instance().logger('Git pushing')
        with self.repository.git.custom_environment(GIT_SSH_COMMAND='ssh -i /home/jonhnanthan/.ssh/id_rsa'):
            self.repository.git.push('origin', '+HEAD')
