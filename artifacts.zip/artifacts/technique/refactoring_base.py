class BaseRefactoring:

    def find_module_in_project(self, project, module_name):
        for file in project.get_files():
            print(file.real_path)
            if module_name in file.real_path:
                return file
